import{M as i}from"./index-B3SlypjZ.js";import{b as n,m as r}from"./web-DOvYsQZW.js";const h={title:"Introducing the New Wino Website!",description:"We're thrilled to announce that Wino, your perfect native replacement for Windows Mail, now has a shiny new home on the web! Our new website is designed to enhance your experience and provide all the information you need about Wino.",thumbnail:"86288.jpg",date:"12/18/2024",author:"Tiktack"};function o(t){const e={h2:"h2",h3:"h3",li:"li",p:"p",strong:"strong",ul:"ul",...i(),...t.components};return[n(e.h2,{children:"Exciting News from Wino!"}),`
`,n(e.p,{children:"We're thrilled to announce that Wino, your perfect native replacement for Windows Mail, now has a shiny new home on the web! Our new website is designed to enhance your experience and provide all the information you need about Wino."}),`
`,n(e.h3,{children:"What’s New?"}),`
`,n(e.ul,{get children(){return[`
`,n(e.li,{get children(){return[n(e.strong,{children:"Landing Page:"})," Discover all the features that make Wino the best choice for Windows 11 users. Our landing page is your go-to spot for learning about Wino’s powerful capabilities and intuitive design."]}}),`
`,n(e.li,{get children(){return[n(e.strong,{children:"Blog:"})," Stay updated with the latest news, tips, and tricks from the Wino team. Our blog is here to help you get the most out of Wino."]}}),`
`,n(e.li,{get children(){return[n(e.strong,{children:"Documentation:"})," Access comprehensive guides and documentation to make your Wino experience smooth and hassle-free. From installation to advanced features, we've got you covered."]}}),`
`]}}),`
`,n(e.h3,{children:"Why Wino?"}),`
`,n(e.p,{children:"Wino is more than just an email client; it's a powerful tool designed to integrate seamlessly with Windows 11. With its intuitive interface and robust features, Wino is here to make your email management effortless."}),`
`,n(e.h3,{children:"Explore Our New Website"}),`
`,n(e.p,{children:"We invite you to explore our new website and see all that Wino has to offer. Stay tuned for more updates, features, and exciting news from the Wino team!"})]}function l(t={}){const{wrapper:e}={...i(),...t.components};return e?n(e,r(t,{get children(){return n(o,t)}})):o(t)}export{l as default,h as frontmatter};
