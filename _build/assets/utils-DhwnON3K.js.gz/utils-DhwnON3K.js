import{b as n,m as a,i as s,t as o}from"./web-U1AJjSeD.js";import{M as i}from"./index-CkDODm8W.js";var l=o('<a href="https://apps.microsoft.com/detail/9NCRCVJC50WL?mode=full"><img src=https://get.microsoft.com/images/en-us%20dark.svg width=200>');const h={title:"Utils",metaTitle:"Utils",order:1};function r(t){const e={a:"a",h1:"h1",h2:"h2",h3:"h3",li:"li",p:"p",span:"span",ul:"ul",...i(),...t.components};return[n(e.h1,{id:"installing-wino-mail",get children(){return[n(e.a,{"aria-hidden":"true",tabIndex:"-1",href:"#installing-wino-mail",get children(){return n(e.span,{className:"icon icon-link"})}}),"Installing Wino Mail"]}}),`
`,n(e.h2,{id:"system-requirements",get children(){return[n(e.a,{"aria-hidden":"true",tabIndex:"-1",href:"#system-requirements",get children(){return n(e.span,{className:"icon icon-link"})}}),"System Requirements"]}}),`
`,n(e.ul,{get children(){return[`
`,n(e.li,{children:"Windows 10 version 1809 or higher"}),`
`,n(e.li,{children:"4GB RAM (minimum)"}),`
`,n(e.li,{children:"100MB free disk space"}),`
`]}}),`
`,n(e.h2,{id:"installation-methods",get children(){return[n(e.a,{"aria-hidden":"true",tabIndex:"-1",href:"#installation-methods",get children(){return n(e.span,{className:"icon icon-link"})}}),"Installation Methods"]}}),`
`,n(e.h3,{id:"microsoft-store-recommended",get children(){return[n(e.a,{"aria-hidden":"true",tabIndex:"-1",href:"#microsoft-store-recommended",get children(){return n(e.span,{className:"icon icon-link"})}}),"Microsoft Store (Recommended)"]}}),`
`,n(e.p,{children:"The recommended way to install Wino Mail is through the Microsoft Store:"}),`
`,s(l),`
`,n(e.h3,{id:"preview-releases",get children(){return[n(e.a,{"aria-hidden":"true",tabIndex:"-1",href:"#preview-releases",get children(){return n(e.span,{className:"icon icon-link"})}}),"Preview Releases"]}})]}function m(t={}){const{wrapper:e}={...i(),...t.components};return e?n(e,a(t,{get children(){return n(r,t)}})):r(t)}export{m as default,h as frontmatter};
